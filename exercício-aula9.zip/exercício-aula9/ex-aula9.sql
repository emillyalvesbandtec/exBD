create table aluno(
ra int primary  key,
nome varchar(40),
telefone varchar(15),
ra_representante int,
fk_projeto int,
foreign key(fk_projeto) references projeto(id_projeto)
);

create table projeto(
id_projeto int primary key auto_increment,
nome varchar(20),
descricao varchar(40)
);

create table acompanhante(
id_acomp int primary key auto_increment,
nome varchar(30),
tipo varchar(20),
fk_aluno int,
foreign key(fk_aluno) references aluno(ra)
);

insert into projeto values	(null,'imunodata','geladeira para armazenaemto de vacinas'),
							(null,'bengala','bengala pra cego'),
                            (null,'techgrao','armazenamento de graos');
					
insert into alunos values 	('0119085','Emilly Santos','11923456433',01192087,1),
							('01192087','Leonardo','11967675675',01192001,2),
                            ('01192001','Italo','1198789876','',3);
                            
insert into acompanhante values	(null,'Marilandia','Mãe',01192085),
								(null,'Samanta','Namorada',01192087),
								(null,'Alan','Namorado',01192001);
                                
select * from aluno;
select * from projeto;
select * from acompanhante;

select * from aluno, projeto where id_projeto = fk_projeto;

select * from aluno as al, acompanhamte as ac where ac.fk_aluno = al.ra;

select ra, nome, telefone, ra_representante from aluno;

select * from aluno as a, projeto as p where a.fk_projeto = p.id_projeto and p.nome = 'imunodata';

select * from aluno as al, projeto as pr, acompanhante as ac where al.fk_projeto = pr.id_pojeto and ac.fk_aluno = al.ra;  






